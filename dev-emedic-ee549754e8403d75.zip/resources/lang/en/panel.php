<?php

return [
    'site_title' => 'Emedic',
];
